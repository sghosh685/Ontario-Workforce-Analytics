# Ontario Workforce Analytics Dashboard

## Project

This project prepares a one-page dashboard titled **Ontario Workforce Snapshot, 2021-2026** using two Statistics Canada monthly labour market tables:

- Table 14-10-0287-01: Labour force characteristics by province, gender, and age group
- Table 14-10-0355-01: Employment by industry, province, and month

The dashboard story:

> Ontario employment has changed since 2021, but the pressure is not the same across every sector. Some industries show stronger employment growth, while others show weaker or more volatile trends. The dashboard helps identify where workforce planning, retraining, and program attention may be needed.

## Folder Structure

```text
Ontario-Workforce-Analytics-Dashboard
├── build_workforce_analytics.py
├── 1410028701_databaseLoadingData.csv
├── 1410035501_databaseLoadingData.csv
├── data_clean
├── charts
└── docs
```

## Outputs

Cleaned data:

- `data_clean/clean_labour_indicators_ontario_2021_2026.csv`
- `data_clean/clean_industry_employment_ontario_2021_2026.csv`
- `data_clean/summary_dashboard_kpis.csv`
- `data_clean/summary_industry_change_jan2021_to_latest.csv`
- `data_clean/summary_industry_yoy_change_latest_month.csv`

Starter charts:

- `charts/01_ontario_employment_trend.png`
- `charts/02_ontario_unemployment_rate_trend.png`
- `charts/03_employment_and_participation_rates.png`
- `charts/04_top_industries_latest_month.png`
- `charts/05_industry_employment_change_since_2021.png`
- `charts/06_industry_yoy_change_latest_month.png`

Important unit note: employment values are in thousands. For example, 8,247.9 means 8,247,900 people.

## Rebuild

Run:

```bash
python3 build_workforce_analytics.py
```

This recreates the cleaned CSV files, charts, and starter ZIP package.

## Suggested Dashboard Layout

Use one page with:

- KPI cards for latest employment, unemployment rate, labour force, participation rate, and employment year-over-year change
- A main employment trend line chart
- A compact unemployment rate trend line chart
- A combined employment/participation rates line chart
- An industry change since January 2021 bar chart
- A latest year-over-year industry change bar chart

